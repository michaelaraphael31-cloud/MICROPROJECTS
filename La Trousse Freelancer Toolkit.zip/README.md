# La Trousse — Freelancer Toolkit

La Trousse is a responsive, frontend-only freelancer workspace created for **25CS208 — Web Technology**. It brings project organization, deadline tracking, simple fee estimates, and a built-in FAQ helper together in one practical digital toolkit.

## Features

- Landing page introducing the toolkit and linking to each page.
- Detailed registration form with field-level client-side validation.
- Simple sign-up form with email, password, and required Terms of Service consent.
- Sign-in prototype with email/password format checks and a show/hide password control.
- Responsive freelancer dashboard with sample projects, due dates, fee totals, sortable projects, editable statuses, and an add/remove project interaction.
- Keyboard-friendly arithmetic calculator (no `eval()`), light/dark theme toggle, and keyword-matching FAQ chat panel.
- No framework, build process, database, external API, or server-side account system.

## Run locally

The site is plain HTML, CSS, and JavaScript. Open `index.html` in a modern browser, or serve this folder with Python's built-in static server:

```powershell
py -m http.server 8000
```

Then open `http://localhost:8000`. No dependencies need to be installed in this project.

## Demo and privacy notes

- Registration and sign-up validate input in the browser only; they do not create an account or securely store credentials.
- Sign-in accepts any valid email format and a password of at least eight characters to display a local demo success message. It does not authenticate anyone.
- Dashboard projects and calculator values are in-memory demo interactions. Reloading the page restores the labeled sample projects.
- Do not enter real personal, password, or client information. No form submits data to a server.
- Theme preference is saved in browser local storage. If browser storage is disabled, the theme still works for the current page view.

## Deploy to Vercel

1. Create a GitHub repository for this project and add these files.
2. Push the project to your repository using your own Git credentials.
3. In Vercel, import the GitHub repository and select the **Other** framework preset (or leave it as a static site).
4. Leave the build command and output directory empty/default; the site is served directly from the project root.
5. Deploy and check the resulting URL on desktop and mobile.

No repository has been created or pushed and no deployment has been performed as part of this project setup.

## Project files

- `index.html` — landing page
- `register.html` — detailed registration form
- `signup.html` — simple sign-up form
- `signin.html` — sign-in prototype
- `home.html` — freelancer dashboard demo
- `styles.css` — shared visual theme, typography, and components
- `layout.css` — responsive layouts and dashboard styling
- `validation.js` — registration, sign-up, and sign-in form validation
- `theme.js` — accessible light/dark mode and preference persistence
- `dashboard.js` — in-page project management and mobile navigation
- `calculator.js` — safe arithmetic and keyboard controls
- `chatbot.js` — floating FAQ helper

## Separate presentation deliverables

Screenshots, the academic report, repository/live links, and QR codes are separate presentation/report deliverables. This website implementation does not create the report, signed certificate, physical printouts, or Google Form submission.
