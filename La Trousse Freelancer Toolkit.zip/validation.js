(() => {
  const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  const validators = {
    fullName: value => /^[a-zA-Z\s]{2,50}$/.test(value.trim()) || 'Enter 2–50 letters and spaces.',
    empId: value => /^[A-Z0-9]{6,12}$/i.test(value.trim()) || 'Use 6–12 letters or numbers.',
    regEmail: value => emailPattern.test(value.trim()) || 'Enter a valid email address.',
    mobile: value => /^[6-9]\d{9}$/.test(value.trim()) || 'Enter a 10-digit mobile number starting with 6–9.',
    dept: value => Boolean(value) || 'Choose a division to continue.',
    regPassword: value => /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(value) || 'Use 8+ characters with uppercase, lowercase, a number, and @$!%*?&.',
    confirmPassword: value => {
      const password = document.getElementById('regPassword');
      return Boolean(value) && password && value === password.value || 'Enter the same password again.';
    },
    signupEmail: value => emailPattern.test(value.trim()) || 'Enter a valid email address.',
    signupPassword: value => value.length >= 8 || 'Use at least 8 characters.',
    signinEmail: value => emailPattern.test(value.trim()) || 'Enter a valid email address.',
    signinPassword: value => value.length >= 8 || 'Password must be at least 8 characters.'
  };

  function validateField(input, forceMessage) {
    const validator = validators[input.id];
    if (!validator) return true;
    const result = validator(input.value);
    const error = document.getElementById(`${input.id}-error`);
    const valid = result === true;
    const showState = forceMessage || input.dataset.touched === 'true' || Boolean(input.value);
    input.classList.toggle('valid', valid && showState);
    input.classList.toggle('invalid', !valid && showState);
    input.setAttribute('aria-invalid', String(!valid && showState));
    if (error) error.textContent = valid || !showState ? '' : result;
    return valid;
  }

  const registerForm = document.getElementById('registration-form');
  if (registerForm) {
    const inputs = [...registerForm.querySelectorAll('input, select')];
    const submit = document.getElementById('register-submit');
    const feedback = document.getElementById('register-feedback');
    const updateForm = forceMessage => {
      let allValid = true;
      inputs.forEach(input => {
        if (!validateField(input, forceMessage)) allValid = false;
      });
      submit.disabled = !allValid;
      return allValid;
    };
    inputs.forEach(input => {
      input.addEventListener('blur', () => {
        input.dataset.touched = 'true';
        validateField(input, true);
        updateForm(false);
      });
      input.addEventListener('input', () => {
        validateField(input, Boolean(input.value));
        updateForm(false);
      });
      input.addEventListener('change', () => {
        input.dataset.touched = 'true';
        validateField(input, true);
        updateForm(false);
      });
    });
    registerForm.addEventListener('submit', event => {
      event.preventDefault();
      if (!updateForm(true)) {
        feedback.textContent = 'Please correct the highlighted fields.';
        return;
      }
      feedback.textContent = 'All fields look good. This prototype does not create or store an account.';
      registerForm.reset();
      inputs.forEach(input => {
        input.classList.remove('valid', 'invalid');
        input.removeAttribute('aria-invalid');
      });
      submit.disabled = true;
    });
    updateForm(false);
  }

  const signupForm = document.getElementById('signup-form');
  if (signupForm) {
    const fields = [...signupForm.querySelectorAll('#signupEmail, #signupPassword')];
    const terms = document.getElementById('terms');
    const termsError = document.getElementById('terms-error');
    const feedback = document.getElementById('signup-feedback');
    fields.forEach(input => {
      input.addEventListener('blur', () => validateField(input, true));
      input.addEventListener('input', () => validateField(input, Boolean(input.value)));
    });
    terms.addEventListener('change', () => {
      termsError.textContent = terms.checked ? '' : 'Please agree to the Terms of Service to continue.';
    });
    signupForm.addEventListener('submit', event => {
      event.preventDefault();
      const valid = fields.map(input => validateField(input, true)).every(Boolean);
      if (!terms.checked) termsError.textContent = 'Please agree to the Terms of Service to continue.';
      if (!valid || !terms.checked) {
        feedback.textContent = 'Check the fields above and try again.';
        return;
      }
      feedback.textContent = 'Looks good! This demo does not create or store an account. Visit the dashboard to explore.';
      signupForm.reset();
      fields.forEach(input => input.classList.remove('valid', 'invalid'));
      termsError.textContent = '';
    });
  }

  const signinForm = document.getElementById('signin-form');
  if (signinForm) {
    const fields = [...signinForm.querySelectorAll('#signinEmail, #signinPassword')];
    const alert = document.getElementById('signin-alert');
    fields.forEach(input => {
      input.addEventListener('blur', () => validateField(input, true));
      input.addEventListener('input', () => {
        validateField(input, Boolean(input.value));
        alert.hidden = true;
      });
    });
    signinForm.addEventListener('submit', event => {
      event.preventDefault();
      const valid = fields.map(input => validateField(input, true)).every(Boolean);
      alert.hidden = false;
      if (!valid) {
        alert.textContent = 'Please enter a valid email address and a password of at least 8 characters.';
        alert.setAttribute('role', 'alert');
        return;
      }
      alert.textContent = 'Demo sign-in successful. This is a local prototype; no account was authenticated.';
      alert.setAttribute('role', 'status');
    });
    const toggle = document.querySelector('[data-password-toggle]');
    const password = document.getElementById('signinPassword');
    toggle.addEventListener('click', () => {
      const show = password.type === 'password';
      password.type = show ? 'text' : 'password';
      toggle.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
      toggle.setAttribute('aria-pressed', String(show));
    });
  }
})();
