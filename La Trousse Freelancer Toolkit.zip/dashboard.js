(() => {
  const list = document.querySelector('[data-project-list]');
  if (!list) return;

  function dateFromToday(offset) {
    const date = new Date();
    date.setHours(12, 0, 0, 0);
    date.setDate(date.getDate() + offset);
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  }
  const initialProjects = [
    { id: 'sample-1', name: 'Brand identity refresh', client: 'North Studio', description: 'A new visual language for an independent creative studio.', dueDate: dateFromToday(2), hours: 24, rate: 50, status: 'In progress', demo: true },
    { id: 'sample-2', name: 'Editorial website', client: 'Field Notes Journal', description: 'A thoughtful home for stories, interviews, and dispatches.', dueDate: dateFromToday(6), hours: 32, rate: 65, status: 'In review', demo: true },
    { id: 'sample-3', name: 'Product launch copy', client: 'Sunday Goods', description: 'Launch messaging and product page copy for a small-batch maker.', dueDate: dateFromToday(10), hours: 16, rate: 45, status: 'Upcoming', demo: true }
  ];
  let projects = [...initialProjects];
  let ascending = true;
  const statusOptions = ['Upcoming', 'In progress', 'In review', 'Completed'];
  const currency = value => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(value);
  const escapeHTML = value => String(value).replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
  function dateLabel(date) {
    if (!date) return 'No date';
    const parsed = new Date(`${date}T12:00:00`);
    return parsed.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  }
  function daysUntil(date) {
    const start = new Date();
    start.setHours(0, 0, 0, 0);
    return Math.ceil((new Date(`${date}T00:00:00`) - start) / 86400000);
  }
  function deadlineText(days) {
    if (days < 0) return 'Overdue';
    if (days === 0) return 'Today';
    if (days === 1) return 'Tomorrow';
    return `In ${days} days`;
  }
  function render() {
    list.innerHTML = projects.map(project => {
      const days = daysUntil(project.dueDate);
      const statusClass = project.status.toLowerCase().replace(/\s+/g, '-');
      return `<article class="project-card" data-project-id="${escapeHTML(project.id)}">
        <div class="project-main"><span class="project-color" aria-hidden="true"></span><div class="project-info"><div class="project-title-row"><h3>${escapeHTML(project.name)}</h3>${project.demo ? '<span class="demo-tag">SAMPLE</span>' : ''}</div>
          <p class="project-client">${escapeHTML(project.client)}</p><p class="project-description-text">${escapeHTML(project.description || 'No description added.')}</p>
          <div class="project-meta"><span>◷ ${dateLabel(project.dueDate)} · ${deadlineText(days)}</span><span>${Number(project.hours)} hrs</span><span class="project-fee">${currency(Number(project.hours) * Number(project.rate))}</span></div></div></div>
        <div class="project-actions"><label class="sr-only" for="status-${escapeHTML(project.id)}">Status for ${escapeHTML(project.name)}</label><select class="project-status status-${statusClass}" id="status-${escapeHTML(project.id)}" data-status-id="${escapeHTML(project.id)}">${statusOptions.map(status => `<option ${status === project.status ? 'selected' : ''}>${status}</option>`).join('')}</select><button class="delete-project" type="button" data-delete-id="${escapeHTML(project.id)}" aria-label="Remove ${escapeHTML(project.name)}">×</button></div>
      </article>`;
    }).join('');
    updateSummary();
    renderDeadlines();
  }
  function updateSummary() {
    const active = projects.filter(project => project.status !== 'Completed');
    document.querySelector('[data-summary-projects]').textContent = String(active.length);
    document.querySelector('[data-nav-count]').textContent = String(projects.length);
    document.querySelector('[data-project-count]').textContent = String(projects.length).padStart(2, '0');
    document.querySelector('[data-summary-fees]').textContent = currency(active.reduce((sum, project) => sum + Number(project.hours) * Number(project.rate), 0));
    const next = active.filter(project => project.dueDate).sort((a, b) => a.dueDate.localeCompare(b.dueDate))[0];
    const deadlineValue = document.querySelector('[data-summary-deadline]');
    const deadlineDescription = document.querySelector('[data-summary-next]');
    if (next) {
      const days = daysUntil(next.dueDate);
      deadlineValue.innerHTML = `${Math.max(0, days)} <small>${days === 1 ? 'day' : 'days'}</small>`;
      deadlineDescription.textContent = `${next.name} · Due ${dateLabel(next.dueDate)}`;
    } else {
      deadlineValue.innerHTML = '—';
      deadlineDescription.textContent = 'No active deadlines';
    }
  }
  function renderDeadlines() {
    const deadlineList = document.querySelector('[data-deadline-list]');
    const upcoming = projects.filter(project => project.status !== 'Completed').sort((a, b) => a.dueDate.localeCompare(b.dueDate)).slice(0, 3);
    deadlineList.innerHTML = upcoming.length ? upcoming.map(project => {
      const parsed = new Date(`${project.dueDate}T12:00:00`);
      return `<article class="deadline-item"><div class="deadline-date"><span>${parsed.toLocaleDateString('en-US', { month: 'short' }).toUpperCase()}</span><b>${parsed.getDate()}</b></div><div class="deadline-copy"><b>${escapeHTML(project.name)}</b><small>${escapeHTML(project.client)}</small></div><span class="deadline-when">${deadlineText(daysUntil(project.dueDate))}</span></article>`;
    }).join('') : '<p class="empty-deadlines">No active deadlines. Add a project to plan ahead.</p>';
  }
  const dateHeading = document.querySelector('.welcome-row .eyebrow');
  const calendarLabel = document.querySelector('.rail-calendar');
  const now = new Date();
  dateHeading.firstChild.textContent = `${now.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' }).toUpperCase()} `;
  calendarLabel.textContent = now.toLocaleDateString('en-US', { month: 'short', year: '2-digit' }).toUpperCase().replace(' ', ' ’');
  list.addEventListener('change', event => {
    const select = event.target.closest('[data-status-id]');
    if (!select) return;
    const project = projects.find(item => item.id === select.dataset.statusId);
    if (project) project.status = select.value;
    render();
  });
  list.addEventListener('click', event => {
    const button = event.target.closest('[data-delete-id]');
    if (!button) return;
    projects = projects.filter(project => project.id !== button.dataset.deleteId);
    render();
  });
  const sortButton = document.querySelector('[data-sort-projects]');
  sortButton.addEventListener('click', () => {
    projects.sort((a, b) => ascending ? a.dueDate.localeCompare(b.dueDate) : b.dueDate.localeCompare(a.dueDate));
    ascending = !ascending;
    sortButton.innerHTML = `Sort by due date <span>${ascending ? '↕' : '↓'}</span>`;
    render();
  });

  const form = document.querySelector('[data-project-form]');
  const feePreview = document.querySelector('[data-live-fee]');
  const hoursField = form.elements.hours;
  const rateField = form.elements.rate;
  function updateFee() {
    const hours = Number(hoursField.value) || 0;
    const rate = Number(rateField.value) || 0;
    feePreview.textContent = currency(hours * rate);
  }
  hoursField.addEventListener('input', updateFee);
  rateField.addEventListener('input', updateFee);
  form.addEventListener('submit', event => {
    event.preventDefault();
    const feedback = document.querySelector('[data-project-feedback]');
    if (!form.reportValidity()) {
      feedback.textContent = 'Please fill in the required project details with valid numbers.';
      return;
    }
    const data = new FormData(form);
    const hours = Number(data.get('hours'));
    const rate = Number(data.get('rate'));
    if (!Number.isFinite(hours) || !Number.isFinite(rate) || hours <= 0 || rate <= 0) {
      feedback.textContent = 'Hours and hourly rate must be greater than zero.';
      return;
    }
    projects.unshift({
      id: `project-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      name: data.get('name').trim(),
      client: data.get('client').trim(),
      description: data.get('description').trim(),
      dueDate: data.get('dueDate'),
      hours,
      rate,
      status: 'Upcoming',
      demo: false
    });
    render();
    form.reset();
    updateFee();
    feedback.textContent = 'Project added to this demo dashboard. It is not saved to a server.';
  });

  const menuToggle = document.querySelector('[data-menu-toggle]');
  const sidebar = document.getElementById('dashboard-sidebar');
  menuToggle.addEventListener('click', () => {
    const isOpen = sidebar.classList.toggle('is-open');
    menuToggle.setAttribute('aria-expanded', String(isOpen));
    menuToggle.setAttribute('aria-label', isOpen ? 'Close navigation menu' : 'Open navigation menu');
  });
  sidebar.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
    sidebar.classList.remove('is-open');
    menuToggle.setAttribute('aria-expanded', 'false');
  }));
  document.addEventListener('click', event => {
    if (window.innerWidth < 768 && sidebar.classList.contains('is-open') && !sidebar.contains(event.target) && !menuToggle.contains(event.target)) {
      sidebar.classList.remove('is-open');
      menuToggle.setAttribute('aria-expanded', 'false');
    }
  });
  render();
})();
