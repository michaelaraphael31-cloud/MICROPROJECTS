(() => {
  const storageKey = 'la-trousse-theme';
  let savedTheme = 'light';
  try {
    const stored = window.localStorage.getItem(storageKey);
    if (stored === 'light' || stored === 'dark') savedTheme = stored;
  } catch (error) {
    console.warn('Theme preference could not be read from local storage.', error);
  }

  function applyTheme(theme) {
    document.documentElement.dataset.theme = theme;
    document.querySelectorAll('.theme-toggle').forEach(button => {
      const dark = theme === 'dark';
      button.setAttribute('aria-label', dark ? 'Switch to light theme' : 'Switch to dark theme');
      button.setAttribute('aria-pressed', String(dark));
      const icon = button.querySelector('.theme-icon');
      if (icon) icon.textContent = dark ? '☀' : '☾';
    });
  }

  applyTheme(savedTheme);
  document.querySelectorAll('.theme-toggle').forEach(button => {
    button.addEventListener('click', () => {
      const theme = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
      applyTheme(theme);
      try {
        window.localStorage.setItem(storageKey, theme);
      } catch (error) {
        console.warn('Theme preference could not be saved.', error);
      }
    });
  });
})();
