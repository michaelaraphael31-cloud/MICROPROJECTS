(() => {
  document.querySelectorAll('[data-chat-widget]').forEach(widget => {
    const panel = widget.querySelector('[data-chat-panel]');
    const toggle = widget.querySelector('[data-chat-toggle]');
    const close = widget.querySelector('[data-chat-close]');
    const form = widget.querySelector('[data-chat-form]');
    const input = widget.querySelector('[data-chat-input]');
    const log = widget.querySelector('[data-chat-log]');
    function scrollLatest() {
      log.scrollTop = log.scrollHeight;
    }
    function addMessage(text, className) {
      const message = document.createElement('div');
      message.className = className;
      message.textContent = text;
      log.appendChild(message);
      scrollLatest();
    }
    function respond(question) {
      const text = question.toLowerCase();
      if (/\b(add|create|new|start)\b/.test(text) && /\b(project|client|work)\b/.test(text)) return 'Use “Add a project” on the dashboard. Enter the project and client names, a due date, estimated hours, and hourly rate; the fee estimate updates for you.';
      if (/\b(fee|price|rate|estimate|cost|calculate)\b/.test(text)) return 'The estimate is your planned hours multiplied by your hourly rate. The dashboard calculator also supports +, −, ×, and ÷ for quick sums.';
      if (/\b(deadline|due|date|track|calendar)\b/.test(text)) return 'Add a due date when you create a project. Your upcoming dates appear in “On the horizon”; you can also sort projects by due date.';
      if (/\b(status|meaning|review|completed|upcoming|progress)\b/.test(text)) return 'Upcoming means work is planned, In progress means it is underway, In review means it needs feedback, and Completed means it is done. Change a project’s status from its dropdown.';
      if (/\b(hello|hi|hey)\b/.test(text)) return 'Hello! Ask me about adding a project, fee estimates, deadlines, or project statuses.';
      return 'I can help with adding projects, calculating fees, tracking deadlines, and understanding project statuses. Try asking about one of those.';
    }
    function openChat() {
      panel.hidden = false;
      toggle.setAttribute('aria-expanded', 'true');
      input.focus();
      scrollLatest();
    }
    function closeChat() {
      panel.hidden = true;
      toggle.setAttribute('aria-expanded', 'false');
      toggle.focus();
    }
    toggle.setAttribute('aria-expanded', 'false');
    toggle.addEventListener('click', () => panel.hidden ? openChat() : closeChat());
    close.addEventListener('click', closeChat);
    form.addEventListener('submit', event => {
      event.preventDefault();
      const question = input.value.trim();
      if (!question) return;
      addMessage(question, 'user-msg');
      input.value = '';
      addMessage(respond(question), 'bot-msg');
      input.focus();
    });
    document.querySelectorAll('.chat-open-link').forEach(link => {
      link.addEventListener('click', event => {
        event.preventDefault();
        openChat();
      });
    });
  });
})();
