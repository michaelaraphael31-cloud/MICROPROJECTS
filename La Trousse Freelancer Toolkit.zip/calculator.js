(() => {
  const calculator = document.querySelector('[data-calculator]');
  if (!calculator) return;
  const display = calculator.querySelector('[data-calc-display]');
  const help = calculator.querySelector('[data-calc-help]');
  let expression = '';
  let resultShown = false;

  function render(value = expression || '0', isError = false) {
    display.textContent = value;
    display.classList.toggle('calc-error', isError);
  }

  function calculate(source) {
    if (!source || !/^[\d+\-*/.\s]+$/.test(source)) throw new Error('Enter a calculation first.');
    const tokens = source.match(/\d*\.?\d+|[+\-*/]/g) || [];
    if (tokens.join('') !== source.replace(/\s/g, '')) throw new Error('Check the numbers and operators.');
    let position = 0;
    function factor() {
      const token = tokens[position++];
      if (token === '+' || token === '-') {
        const value = factor();
        return token === '-' ? -value : value;
      }
      const value = Number(token);
      if (token === undefined || !Number.isFinite(value)) throw new Error('Check the calculation format.');
      return value;
    }
    function term() {
      let value = factor();
      while (tokens[position] === '*' || tokens[position] === '/') {
        const operator = tokens[position++];
        const next = factor();
        if (operator === '/' && next === 0) throw new Error('Cannot divide by zero.');
        value = operator === '*' ? value * next : value / next;
      }
      return value;
    }
    function sum() {
      let value = term();
      while (tokens[position] === '+' || tokens[position] === '-') {
        const operator = tokens[position++];
        const next = term();
        value = operator === '+' ? value + next : value - next;
      }
      return value;
    }
    const value = sum();
    if (position !== tokens.length || !Number.isFinite(value)) throw new Error('Check the calculation format.');
    return Number(value.toPrecision(10)).toString();
  }

  function handleKey(key) {
    display.classList.remove('calc-error');
    help.textContent = 'Keyboard ready · Enter to calculate';
    if (key === 'C' || key === 'Escape') {
      expression = '';
      resultShown = false;
      render();
      return;
    }
    if (key === '=') {
      try {
        expression = calculate(expression);
        resultShown = true;
        render(expression);
      } catch (error) {
        render(error.message, true);
        help.textContent = 'Clear and try a different calculation.';
      }
      return;
    }
    if (/^\d$/.test(key) || key === '.') {
      if (resultShown) expression = '';
      resultShown = false;
      if (key === '.' && /(?:^|[+\-*/])\d*\.\d*$/.test(expression)) return;
      expression += key;
      render();
      return;
    }
    if (/^[+\-*/]$/.test(key)) {
      resultShown = false;
      if (!expression && key !== '-') return;
      if (/[+\-*/]$/.test(expression)) expression = expression.slice(0, -1);
      expression += key;
      render();
    }
  }

  calculator.addEventListener('click', event => {
    const button = event.target.closest('[data-calc-key]');
    if (button) handleKey(button.dataset.calcKey);
  });
  document.addEventListener('keydown', event => {
    if (event.altKey || event.ctrlKey || event.metaKey) return;
    const focused = document.activeElement;
    if (focused && /INPUT|TEXTAREA|SELECT/.test(focused.tagName)) return;
    if (/^[0-9.+\-*/]$/.test(event.key)) {
      event.preventDefault();
      handleKey(event.key);
    } else if (event.key === 'Enter' || event.key === '=') {
      event.preventDefault();
      handleKey('=');
    } else if (event.key === 'Escape' || event.key === 'Backspace') {
      event.preventDefault();
      if (event.key === 'Escape') handleKey('C');
      else {
        expression = expression.slice(0, -1);
        render();
      }
    }
  });
})();
